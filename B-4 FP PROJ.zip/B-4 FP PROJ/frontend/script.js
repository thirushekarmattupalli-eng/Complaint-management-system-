// Default admin credentials
const adminUser = "admin";
const adminPass = "admin123";

// Initialize complaints in localStorage
if (!localStorage.getItem("complaints")) {
  localStorage.setItem("complaints", JSON.stringify([]));
}

// LOGIN FUNCTION
function login() {
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;

  if (username === adminUser && password === adminPass) {
    alert("Admin Login Successful");
    window.location.href = "admin.html";
  }
  else if (username !== "" && password !== "") {
    alert("User Login Successful");
    window.location.href = "dashboard.html";
  }
  else {
    alert("Invalid Login Details");
  }
}

// REGISTER FUNCTION
function registerUser() {
  let fullname = document.getElementById("fullname").value;
  let username = document.getElementById("regUsername").value;
  let email = document.getElementById("regEmail").value;
  let password = document.getElementById("regPassword").value;

  if (fullname === "" || username === "" || email === "" || password === "") {
    alert("Please fill all fields");
    return;
  }

  alert("Registered Successfully");
  window.location.href = "login.html";
}

// SUBMIT COMPLAINT
function submitComplaint() {
  let name = document.getElementById("name").value;
  let contact = document.getElementById("contact").value;
  let description = document.getElementById("description").value;

  if (name === "" || contact === "" || description === "") {
    alert("Please fill all fields");
    return;
  }

  let complaints = JSON.parse(localStorage.getItem("complaints"));

  let newComplaint = {
    id: "C" + String(complaints.length + 1).padStart(3, '0'),
    name: name,
    contact: contact,
    description: description
  };

  complaints.push(newComplaint);

  localStorage.setItem("complaints", JSON.stringify(complaints));

  alert("Complaint Submitted Successfully");
  window.location.reload();
}

// LOAD COMPLAINTS
function loadComplaints() {
  let complaints = JSON.parse(localStorage.getItem("complaints"));
  let table = document.getElementById("complaintTable");

  table.innerHTML = `
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Contact</th>
      <th>Description</th>
    </tr>
  `;

  complaints.forEach(c => {
    let row = table.insertRow();
    row.insertCell(0).innerText = c.id;
    row.insertCell(1).innerText = c.name;
    row.insertCell(2).innerText = c.contact;
    row.insertCell(3).innerText = c.description;
  });
}
