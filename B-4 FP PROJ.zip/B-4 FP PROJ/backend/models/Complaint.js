const mongoose = require("mongoose");

const ComplaintSchema = new mongoose.Schema({
  name: String,
  contact: String,
  description: String,
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Complaint", ComplaintSchema);