const router = require("express").Router();
const Complaint = require("../models/Complaint");

// ADD Complaint
router.post("/", async (req, res) => {
  const complaint = new Complaint(req.body);
  await complaint.save();
  res.json({ message: "Complaint Added" });
});

// GET ALL
router.get("/", async (req, res) => {
  const complaints = await Complaint.find();
  res.json(complaints);
});

module.exports = router;