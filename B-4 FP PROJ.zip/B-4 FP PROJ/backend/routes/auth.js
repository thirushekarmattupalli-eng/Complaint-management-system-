const router = require("express").Router();
const User = require("../models/User");

// REGISTER
router.post("/register", async (req, res) => {
  const newUser = new User(req.body);
  await newUser.save();
  res.json({ message: "User Registered" });
});

// LOGIN
router.post("/login", async (req, res) => {
  const user = await User.findOne({
    username: req.body.username,
    password: req.body.password
  });

  if (!user) return res.status(400).json({ message: "Invalid credentials" });

  res.json({ message: "Login Success", role: user.role });
});

module.exports = router;